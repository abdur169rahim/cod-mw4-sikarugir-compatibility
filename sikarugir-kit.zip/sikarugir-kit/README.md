# COD: MW4 Mac Compatibility - Sikarugir kit (0.3-sikarugir)

For engine **WS12WineSikarugir11.0_1** (Wine 11.0, revision 1) and releases **0.1** and **1** of
"COD: MW4 Mac Compatibility". Tested only against the real engine files and the real release files, never on a
Mac or with the game - see "What is not verified".

See **GUIDE.md** for the full step-by-step guide.

## Commands

| Command | What it does |
| --- | --- |
| `check <wrapper.app> [sp26 folder]` | Report only. Changes nothing. Saves `sikarugir-report.txt`. |
| `patch-helper <sp26 folder>` | Adapts `MW4-Compatibility.exe` (release 0.1 or 1) so the CrossOver-only audio step cannot stop the launch. Keeps a backup. |
| `audio-fix <wrapper.app>` | Applies the author's one-instruction audio fix to the wrapper's own `winecoreaudio.so`. Backup kept. |
| `audio-undo <wrapper.app>` | Undoes `audio-fix`. |
| `shader-hook <wrapper.app> <sp26.dylib>` | Makes the wrapper's Wine load the shader component (`sp26.dylib`). This is the step CrossOver's own setup performs. Backs up `ntdll.so`. |
| `shader-undo <wrapper.app>` | Undoes `shader-hook`. |
| `run-log <wrapper.app>` | Starts the wrapper from Terminal, saves everything Wine prints to `mw4-wine-log.txt` and says whether the shader component loaded and hooked D3DMetal. |

Run them as `perl sikarugir-kit.pl <command> ...`. Tip: after typing the command name, drag the `.app`, folder or file
from Finder into Terminal to paste its path.

## Why `shader-hook` exists

The helper's shader component fixes the graphics layer (it hides a capability D3DMetal advertises but cannot deliver
correctly, and replaces two compute shaders). It only works if Wine loads it at start-up. CrossOver's setup arranges
that by editing a copy of `ntdll.so`; Sikarugir never had that step, so the game ran without these fixes.

## Typical order

1. `check` (look at sections 5 and 6).
2. `patch-helper` (once per helper file).
3. `audio-fix` (once).
4. `shader-hook` with the `sp26.dylib` of the release you want (release 1 is a superset of 0.1).
5. Launch the wrapper (Program `MW4-Compatibility.exe`, arguments `--prepared --game-dir "<Windows path>"`, or the
   generated `Play-MW4-Sikarugir.bat`).

## Undo everything
- Helper: delete `MW4-Compatibility.exe`, rename the `.original` backup back.
- `audio-undo` and `shader-undo` restore the wrapper's own files.

## What is not verified
- Nothing was run on a Mac or with the game. `codesign` was not available where this was built.
- The shader component only installs its hooks if D3DMetal's code matches (section 5 of `check` tells you).
- The release's cache/connectivity step and the Ultra Textures downloader are not part of this kit.
