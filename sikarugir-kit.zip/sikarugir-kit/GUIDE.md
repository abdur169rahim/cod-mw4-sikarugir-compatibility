# Running Call of Duty: Modern Warfare 4 on a Mac with Sikarugir

*Community guide, October 2026. Not affiliated with Activision, Apple, CodeWeavers or the Sikarugir project. Use at your own risk.*

## 1. What this guide is

A community patch makes the MW4 campaign playable on Mac. It was written for CrossOver Preview. This guide shows how to use it in a Sikarugir wrapper, with a small helper script (`sikarugir-kit.pl`) that adapts the patch to Sikarugir’s Wine engine.

**Tested on:** MacBook Pro M4 Pro (24 GB), macOS 27, Sikarugir wrapper 1.0.24, engine WS12WineSikarugir11.0_1, D3DMetal 4.0b3 with MSync on. The campaign runs at about 60 FPS at 1512x982 once variable rate shading is turned off in lowest graphics.

**Not tested:** other Macs or engines, multiplayer, and the helper from patch release 1 (only the release 0.1 helper has been run).

## 2. What you need

- An Apple Silicon Mac with macOS 26 and avobe (the tested version is 26.6.2) and Rosetta. 24 GB of memory is recommended: the game used about 21 GB at maximum texture quality.
- Sikarugir, with a wrapper created using the engine **WS12WineSikarugir11.0_1**.
-  the game folder must be moved  inside the wrapper’s C: drive then program files `C:\Program Files\Call of Duty - Modern Warfare 4`.
- The patch files from the patch author’s download page: `MW4-Compatibility.exe` and `sp26.dylib`. go and download the compatibility files from (https://github.com/mchdkose/cod-mw4-mac-compatibility)
- `sikarugir-kit.pl`, the helper script that goes with this guide.

## 3. Wrapper settings

In the wrapper’s options:
- turn on retina mode.
- Graphics: **D3DMetal**.
- Turn **MSync** on.
- Close other large apps before playing.


## 4. Copy the patch files

Copy `MW4-Compatibility.exe` and `sp26.dylib` into the game’s `sp26` folder, next to `sp26-cod.exe` . To find it: right-click the wrapper in Finder, choose Show Package Contents, then open Contents, SharedSupport, prefix, drive_c, Program Files, the game folder and `sp26`.

## 5. Terminal basics

Open Terminal (Cmd+Space, type Terminal). Put `sikarugir-kit.pl` in your Downloads folder, then run:

```
cd ~/Downloads
```

To avoid typing long paths, type the command and a space, then drag the wrapper or folder from Finder into the Terminal window. Keep paths in single quotes when they contain spaces.

## 6. Run the kit

Quit the wrapper first. In the commands below, `<wrapper>` is the path of the wrapper `.app` and `<sp26>` is the path of the `sp26` folder.

**Step A: check (changes nothing)**

```
perl sikarugir-kit.pl check '<wrapper>' '<sp26>'
```

Read the report. It saves `sikarugir-report.txt` and shows whether the engine matches, whether your D3DMetal build matches (section 5 of the report) and which patch release recognises your game build (section 6). If no release recognises your game build, stop here.

**Step B: adapt the helper** (keeps a `.original` backup)

```
perl sikarugir-kit.pl patch-helper '<sp26>'
```

**Step C: apply the audio fix** (backup kept)

```
perl sikarugir-kit.pl audio-fix '<wrapper>'
```

**Step D: install the shader component**, using the `sp26.dylib` from the newest patch release you have

```
perl sikarugir-kit.pl shader-hook '<wrapper>' '/path/to/sp26.dylib'
```

Run the check again afterwards. Section 5 should say the shader component is installed and that all D3DMetal code windows match.

## 7. Launch settings

In the wrapper, set the program to run to:

 `Play-MW4-Sikarugir.bat` from sp26 folder. Step B creates it.

A healthy start writes `compatibility.log` in the `sp26` folder with these lines: `REX_CODE_READY`, `GPU_GUARD_READY`, `INPUT_WAIT_READY`, `COMPATIBILITY_READY`. Sikarugir’s last-run Wine log (`LastRunWine.log`) should contain lines starting with `SP26_` showing the shader component hooked D3DMetal.

## 8. In-game settings

| Setting | Suggestion | Why |
| --- | --- | --- |
| Variable rate shading | **Off** | With it on, 3D scenes show black flickering speckles over textures, while menus and cutscenes stay clean. |
| Ray tracing | Off | Largest GPU cost. |
| Upscaler and resolution | Try 1920x1200 with fsr 3  upscaler. The upscaling might get glitchy . I cant guarantee that it will work. Mine did not work at first | 
| VRAM scale target, texture quality | About 70 to 80%, one step below maximum on a 24 GB Mac | The game can use most of your memory at maximum quality. |
| Background shader preloading | On | Let it finish before playing to reduce stutter. |
| Frame rate | Cap at 60 | Steadier than relying on V-Sync alone. |

Watch Activity Monitor’s Memory Pressure graph while you play. If it turns yellow or red, lower texture quality or close other apps.

## 9. Troubleshooting

| Symptom | Likely cause | Fix |
| --- | --- | --- |
| The helper stops at once, or `compatibility.log` never reaches `COMPATIBILITY_READY` | The helper’s CrossOver-only audio step failed | Run Step B, then check `compatibility.log` again. |
| The helper says the EXE is unsupported | Your game build is not one the helper release knows | The check report (section 6) shows which release recognises your build. |
| Black flickering speckles on 3D textures | Variable rate shading is on | Turn it off in the game’s graphics settings. |
| No `SP26_` lines in the Wine log | The shader component is not installed or D3DMetal differs | Run the check again and read section 5. |
| Stutter, or Memory Pressure goes yellow or red | The game is using most of your memory | Lower texture quality or the VRAM scale target and close other apps. |
| Odd audio after Step C | The audio fix does not suit your setup | Run the audio-undo command. |

## 10. Undo everything

```
perl sikarugir-kit.pl audio-undo '<wrapper>'
perl sikarugir-kit.pl shader-undo '<wrapper>'
```

For the helper, delete `MW4-Compatibility.exe` in the `sp26` folder and rename `MW4-Compatibility.exe.original` back to `MW4-Compatibility.exe`.

## 11. What this guide does not cover:
Ultra textures from the original author. Go to his GitHub page and set it up if you want. My sikarugir patch doesn't need it for the game to work. But the game is unplayable without it. Highly recommended. 

## 12. Notes

The kit has been checked against the real Sikarugir engine files and the real patch releases, and the steps above were followed on one Mac. It has not been tested more widely, so expect some differences on other setups. Credit for the original compatibility patch goes to its author on GitHub and Reddit. (https://github.com/mchdkose/cod-mw4-mac-compatibility)

