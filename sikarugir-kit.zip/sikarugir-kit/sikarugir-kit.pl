#!/usr/bin/perl
# ============================================================================
#  COD: MW4 Mac Compatibility  -  Sikarugir kit  (version 0.3-sikarugir)
#
#  Made for: Sikarugir engine WS12WineSikarugir11.0_1 (Wine 11.0, revision 1)
#  Works with: releases 0.1 and 1 of "COD: MW4 Mac Compatibility"
#
#  What it does (7 commands):
#    check         Look at your wrapper + game folder and print a report.
#                  Changes NOTHING.
#    patch-helper  Make MW4-Compatibility.exe skip its CrossOver-only audio
#                  routing step (a backup copy is kept).
#    audio-fix     Apply the author's one-instruction audio fix directly to the
#                  wrapper's own winecoreaudio.so (a backup copy is kept).
#    audio-undo    Put the original winecoreaudio.so back.
#    shader-hook   Load the shader component (sp26.dylib) into the wrapper's Wine,
#                  the step CrossOver's own setup does but Sikarugir never did.
#                  (ntdll.so is backed up first.)
#    shader-undo   Put the original ntdll.so back and remove sp26.dylib.
#    run-log       Start the wrapper from Terminal, save everything Wine prints to
#                  mw4-wine-log.txt and tell you whether the shader component
#                  loaded and hooked D3DMetal.
#
#  Needs only the Perl and codesign that ship with macOS.
# ============================================================================
use strict;
use warnings;
use File::Find;
use File::Copy qw(copy);
use File::Basename qw(basename dirname);
use Digest::SHA;
use Cwd qw(abs_path getcwd);

my $KIT_VERSION = '0.3-sikarugir';

# ---- Facts about the helper releases this kit knows ------------------------
my $HELPER_NAME = 'MW4-Compatibility.exe';
# In every release the helper asks "did the CrossOver-only audio routing work?" and
# stops the launch if not. The change below makes the answer count as "yes".
#   release 0.1: "je <success>"  becomes  "jmp <success>"
#   release 1  : the result-code jump table is forced to entry 0 (= success)
# 'games' = SHA-256 fingerprints of sp26-cod.exe that release recognises.
my @HELPERS = (
  { name => '0.1', size => 84060,
    sha256 => '84a1613ea2e47e4461c90f1d299d39cf9d4e3a8b25773ab18381b168ff47a14d',
    offset => 0x3bd1, orig => "\x0f\x84\x68\x0c\x00\x00", new => "\xe9\x69\x0c\x00\x00\x90",
    games  => ['6eaeb2a8772b1ca5402c7c06c49748e969cd9073a9ff3d82b72d4aa46e4869ca',
               '69bca6d6e9dd874d0e9b194a300f1ddf9ffc264b1081f78e0e4e7d7ff4c0408e'] },
  { name => '1', size => 101433,
    sha256 => '08b5231f4b683a9a58411e18c942ab0d5ef5723b612e15006b6cf89a99a0427a',
    offset => 0x4c89, orig => "\x83\xfd\x06\x0f\x87\x43\x05\x00\x00", new => "\x45\x31\xf6\x90\x90\x90\x90\x90\x90",
    games  => ['20ed038001ca6c5731ec70a4c2553c7493a58ff413c7277050bb5883feff7fc4',
               'cd2bec4f40cbdf8aacdbc7917634d3600eca64b82018baea49aacf06c52ce915'] },
);
# Known sp26.dylib builds (SHA-256 -> release)
my %KNOWN_DYLIB = (
    '1bad0cdeaab732376aa7345305f980ee4ba9906a0ed5cb0b954acbf377bf51d0' => '0.1',
    'ff5d742a912683e48342986644139ed7805a2aeaf8978a7fc60c242fa4d69819' => '1',
);

# Bytes of Wine's KiUserExceptionDispatcher (inside ntdll.dll) the helper insists on
my %DISPATCH = (0=>0xfc,1=>0x48,2=>0x8b,3=>0x05,26=>0x48,27=>0x89,28=>0xe2,29=>0x48,
                30=>0x8d,31=>0x8c,32=>0x24,33=>0xf0,34=>0x04,35=>0x00,36=>0x00,37=>0xe8,42=>0xcc);

# mmdevapi.dll identity the helper's built-in audio routing insists on (CrossOver Preview)
my %CX_MMDEVAPI = (timestamp=>0, size_of_image=>0x2d000, checksum=>0x376cc);

# D3DMetal build that the shader component (sp26.dylib) was written for
my $D3DMETAL_UUID = '4418ec47-c3f0-3285-a056-15d87d785ffe';

# 64-byte windows of D3DMetal code that the shader component verifies before it hooks
# anything: [linked address, hex bytes]  (taken from the release-1 source, method_bytes.h)
my @METHOD_WINDOWS = (
    [0x70a32, '4883c1f0e941a500004883c1f0e98ea3000089d083e0fe31c983fa02ba180000000f43d183f802b8120000000f45c2c34883c1f0e915a200004885d27408488b'],
    [0x80d29, '4883ec28488b0f4883c1f08b57084c8b4710448b4f18e838a2ffff89471c31c04883c428c34883ec28488b0f488b57084883c1f04c8b47104c8b4f18e868a0ff'],
    [0x70a20, '4883c1f0e907b300004883c1f0e94eaf00004883c1f0e941a500004883c1f0e98ea3000089d083e0fe31c983fa02ba180000000f43d183f802b8120000000f45'],
    [0x80ccf, '4883ec28488b0f488b57084883c1f04c8b47104c8b4f18e845b0ffff89472031c04883c428c34883ec38488b0f4883c1f0448b470c4c8b4f100f104718488b47'],
    [0x713a5, '4883c1f0e9e05a00004883c1f0e90758000048833d69474c00ff7506b801400080c356574881eca8000000440f29bc2490000000440f29b42480000000440f29'],
    [0x81386, '4883ec28488b0f488b57084883c1f04c8b47104c8b4f18e8ec5affff89472031c04883c428c34883ec28488b0f488b57084883c1f04c8b47104c8b4f18e8f657'],
    [0x6588c, '4883c1f0e9972300004883c1f0e94e2200004883c1f0e9c12000004883c1f0e90000000041574156415541545657534881ec800a0000440f29bc24700a000044'],
    [0x68f60, '4883ec28488b0f488b57084883c1f04c8b47104c8b4f18488b47204889442420e8a7ecffff89472831c04883c428c34883ec28488b0f4883c1f0e84debffff48'],
    [0x658a7, '4883c1f0e90000000041574156415541545657534881ec800a0000440f29bc24700a0000440f29b424600a0000440f29ac24500a0000440f29a424400a000044'],
    [0x68fcc, '4883ec28488b0f488b57084883c1f04c8b47104c8b4f18488b47204889442420e8bfc8ffff89472831c04883c428c390e96753000090534889fbe85d53000048'],
);

# ---- small helpers ---------------------------------------------------------
my @REPORT;
sub out  { my $l = join('', @_); print "$l\n"; push @REPORT, $l; }
sub okl  { out('  [ OK ]    ', @_); }
sub note { out('  [ NOTE ]  ', @_); }
sub bad  { out('  [ FAIL ]  ', @_); }

sub slurp {
    my ($p) = @_;
    open(my $f, '<:raw', $p) or die "Cannot read $p: $!\n";
    local $/; my $d = <$f>; close $f; return $d;
}
sub spew {
    my ($p, $d, $mode) = @_;
    open(my $f, '>:raw', $p) or die "Cannot write $p: $!\n";
    print $f $d; close $f or die "Cannot save $p: $!\n";
    chmod($mode, $p) if defined $mode;
}
sub file_sha256 {
    my ($p) = @_;
    open(my $f, '<:raw', $p) or return undef;
    my $s = Digest::SHA->new(256); $s->addfile($f); close $f;
    return $s->hexdigest;
}
sub read_at {
    my ($p, $off, $len) = @_;
    open(my $f, '<:raw', $p) or return undef;
    seek($f, $off, 0) or return undef;
    my $b = ''; read($f, $b, $len); close $f; return $b;
}
sub strip_slash { my ($p) = @_; $p =~ s{/+$}{} if length($p) > 1; return $p; }

# ---- PE (Windows DLL) reading ----------------------------------------------
sub pe_info {
    my ($d) = @_;
    return undef unless length($d) > 0x200 && substr($d, 0, 2) eq 'MZ';
    my $pe = unpack('V', substr($d, 0x3c, 4));
    return undef unless substr($d, $pe, 4) eq "PE\0\0";
    my $nsec   = unpack('v', substr($d, $pe + 6, 2));
    my $stamp  = unpack('V', substr($d, $pe + 8, 4));
    my $optsz  = unpack('v', substr($d, $pe + 20, 2));
    my $opt    = $pe + 24;
    return undef unless unpack('v', substr($d, $opt, 2)) == 0x20b;      # 64-bit PE only
    my $size_of_image = unpack('V', substr($d, $opt + 56, 4));
    my $checksum      = unpack('V', substr($d, $opt + 64, 4));
    my ($exp_rva, $exp_size) = unpack('V2', substr($d, $opt + 112, 8));
    my @secs;
    for my $i (0 .. $nsec - 1) {
        my $o = $pe + 24 + $optsz + $i * 40;
        my ($vsz, $va, $rsz, $rp) = unpack('V4', substr($d, $o + 8, 16));
        push @secs, [$va, $vsz, $rp, $rsz];
    }
    return { stamp=>$stamp, size_of_image=>$size_of_image, checksum=>$checksum,
             exp_rva=>$exp_rva, secs=>\@secs };
}
sub pe_off {
    my ($pi, $rva) = @_;
    for my $s (@{ $pi->{secs} }) {
        my ($va, $vsz, $rp, $rsz) = @$s;
        my $span = $vsz > $rsz ? $vsz : $rsz;
        return $rp + $rva - $va if $rva >= $va && $rva < $va + $span;
    }
    return undef;
}
sub pe_export_bytes {                      # first $n bytes of an exported function
    my ($d, $pi, $name, $n) = @_;
    return undef unless $pi->{exp_rva};
    my $ed = pe_off($pi, $pi->{exp_rva}); return undef unless defined $ed;
    my ($nfun, $nnames, $afun, $anames, $aord) = unpack('V5', substr($d, $ed + 20, 20));
    my ($of, $on, $oo) = (pe_off($pi, $afun), pe_off($pi, $anames), pe_off($pi, $aord));
    return undef unless defined $of && defined $on && defined $oo;
    for my $i (0 .. $nnames - 1) {
        my $nrva = unpack('V', substr($d, $on + 4 * $i, 4));
        my $noff = pe_off($pi, $nrva); next unless defined $noff;
        my $nm = unpack('Z*', substr($d, $noff, 64));
        next unless $nm eq $name;
        my $ord = unpack('v', substr($d, $oo + 2 * $i, 2));
        my $frva = unpack('V', substr($d, $of + 4 * $ord, 4));
        my $foff = pe_off($pi, $frva); return undef unless defined $foff;
        return substr($d, $foff, $n);
    }
    return undef;
}

# ---- Mach-O (macOS binary) UUID --------------------------------------------
sub macho_uuid {
    my ($path) = @_;
    my $head = read_at($path, 0, 4096); return undef unless defined $head && length($head) >= 8;
    my $base = 0;
    if (unpack('N', substr($head, 0, 4)) == 0xcafebabe) {                 # "fat" file
        my $n = unpack('N', substr($head, 4, 4)); my $pick;
        for my $i (0 .. $n - 1) {
            last if 8 + $i * 20 + 20 > length($head);
            my ($ct, $cs, $off) = unpack('N3', substr($head, 8 + $i * 20, 12));
            $pick = $off if !defined $pick;
            if ($ct == 0x01000007) { $pick = $off; last; }                # prefer x86_64
        }
        return undef unless defined $pick; $base = $pick;
    }
    my $mh = read_at($path, $base, 32); return undef unless defined $mh && length($mh) == 32;
    return undef unless unpack('V', substr($mh, 0, 4)) == 0xfeedfacf;
    my ($ncmds, $szc) = unpack('V2', substr($mh, 16, 8));
    return undef if $szc > 1_000_000;
    my $cmds = read_at($path, $base + 32, $szc); return undef unless defined $cmds;
    my $at = 0;
    for (1 .. $ncmds) {
        last if $at + 8 > length($cmds);
        my ($cmd, $size) = unpack('V2', substr($cmds, $at, 8));
        last if $size < 8;
        if ($cmd == 0x1b && $size >= 24) {
            my $u = unpack('H32', substr($cmds, $at + 8, 16));
            return join('-', substr($u,0,8), substr($u,8,4), substr($u,12,4), substr($u,16,4), substr($u,20,12));
        }
        $at += $size;
    }
    return undef;
}

# ---- Finding things inside a Sikarugir wrapper -----------------------------
sub skip_dirs { return grep { $_ ne 'drive_c' && $_ ne 'dosdevices' } @_; }

sub locate_engine {                       # returns ($engine_root, $how_many_found)
    my ($arg) = @_;
    $arg = strip_slash($arg);
    die "Folder not found: $arg\n" unless -d $arg;
    return ($arg, 1) if -f "$arg/lib/wine/x86_64-unix/winecoreaudio.so";
    my @hits;
    find({ no_chdir => 1, preprocess => sub { skip_dirs(@_) },
           wanted => sub {
               push @hits, $File::Find::name
                   if $File::Find::name =~ m{/lib/wine/x86_64-unix/winecoreaudio\.so$} && -f $File::Find::name;
           } }, $arg);
    die "Could not find a Wine engine inside:\n  $arg\n"
      . "Give me the wrapper (the .app) that you use for Modern Warfare 4.\n" unless @hits;
    (my $root = $hits[0]) =~ s{/lib/wine/x86_64-unix/winecoreaudio\.so$}{};
    return ($root, scalar @hits);
}

sub find_d3dmetal {
    my ($root) = @_;
    my (%seen, @out);
    find({ no_chdir => 1, preprocess => sub { skip_dirs(@_) },
           wanted => sub {
               my $p = $File::Find::name;
               return unless basename($p) eq 'D3DMetal' && -f $p;
               my $rp = abs_path($p) // $p; return if $seen{$rp}++;
               push @out, $p;
           } }, $root);
    return @out;
}

# The author's audio fix: in the ring-buffer code of winecoreaudio.so,
#   mov eax,0 ; cmova eax,esi   becomes   mov eax,0 ; nop nop nop
# The surrounding bytes are identical in CrossOver and Sikarugir; only a struct
# offset differs, so we search for the pattern instead of using a fixed position.
sub find_audio_sites {
    my ($d) = @_;
    my @sites;
    while ($d =~ /\x39\x53(.)\xb8\x00\x00\x00\x00(\x0f\x47\xc6|\x90\x90\x90)\x01\xd0\x89\x43(.)\x89\xf1\xe9/gs) {
        my ($start, $d1, $kind, $d2) = ($-[0], $1, $2, $3);
        next unless $d1 eq $d2;
        push @sites, { at => $start + 8, patched => ($kind eq "\x90\x90\x90" ? 1 : 0) };
    }
    return @sites;
}

sub codesign_identifier {
    my ($p) = @_;
    return '' unless -x '/usr/bin/codesign';
    my $t = `/usr/bin/codesign -dv "$p" 2>&1`;
    return ($t =~ /^Identifier=(\S+)/m) ? $1 : '';
}
sub codesign_ad_hoc {
    my ($p, $ident) = @_;
    my @cmd = ('/usr/bin/codesign', '--force', '--sign', '-');
    push @cmd, ('--identifier', $ident) if length $ident;
    push @cmd, $p;
    return system(@cmd) == 0;
}
sub codesign_verify { my ($p) = @_; return system('/usr/bin/codesign', '--verify', '--strict', $p) == 0; }

sub identify_helper {                     # returns ($release_hashref, 'original'|'adapted') or ()
    my ($d) = @_;
    for my $h (@HELPERS) {
        next unless length($d) == $h->{size};
        return ($h, 'original') if Digest::SHA::sha256_hex($d) eq $h->{sha256};
        if (substr($d, $h->{offset}, length($h->{new})) eq $h->{new}) {
            my $o = $d; substr($o, $h->{offset}, length($h->{orig})) = $h->{orig};
            return ($h, 'adapted') if Digest::SHA::sha256_hex($o) eq $h->{sha256};
        }
    }
    return ();
}

# Compare the 64-byte code windows of the user's D3DMetal against the ones the shader
# component was written for.  Returns ($matching, $total, $why_not_readable)
sub d3dmetal_method_check {
    my ($path) = @_;
    my $head = read_at($path, 0, 4096); return (0, scalar(@METHOD_WINDOWS), 'unreadable') unless defined $head && length($head) >= 8;
    my $base = 0;
    if (unpack('N', substr($head, 0, 4)) == 0xcafebabe) {
        my $n = unpack('N', substr($head, 4, 4)); my $pick;
        for my $i (0 .. $n - 1) {
            last if 8 + $i * 20 + 20 > length($head);
            my ($ct, $cs, $off) = unpack('N3', substr($head, 8 + $i * 20, 12));
            $pick = $off if !defined $pick;
            if ($ct == 0x01000007) { $pick = $off; last; }
        }
        return (0, scalar(@METHOD_WINDOWS), 'no slice') unless defined $pick; $base = $pick;
    }
    my $mh = read_at($path, $base, 32);
    return (0, scalar(@METHOD_WINDOWS), 'not a 64-bit Mach-O') unless defined $mh && length($mh) == 32 && unpack('V', substr($mh, 0, 4)) == 0xfeedfacf;
    return (0, scalar(@METHOD_WINDOWS), 'not an x86_64 binary') unless unpack('V', substr($mh, 4, 4)) == 0x01000007;
    my ($ncmds, $szc) = unpack('V2', substr($mh, 16, 8));
    my $cmds = read_at($path, $base + 32, $szc); return (0, scalar(@METHOD_WINDOWS), 'header unreadable') unless defined $cmds;
    my (@segs, $at);
    $at = 0;
    for (1 .. $ncmds) {
        last if $at + 8 > length($cmds);
        my ($cmd, $size) = unpack('V2', substr($cmds, $at, 8)); last if $size < 8;
        if ($cmd == 0x19 && $size >= 72) { my ($va, $vsz, $fo, $fsz) = unpack('Q<4', substr($cmds, $at + 24, 32)); push @segs, [$va, $vsz, $fo, $fsz]; }
        $at += $size;
    }
    my $good = 0;
    for my $w (@METHOD_WINDOWS) {
        my ($addr, $hex) = @$w; my $want = pack('H*', $hex);
        for my $sg (@segs) {
            my ($va, $vsz, $fo, $fsz) = @$sg;
            next unless $addr >= $va && $addr + 64 <= $va + $vsz && ($addr - $va) + 64 <= $fsz;
            my $got = read_at($path, $base + $fo + ($addr - $va), 64);
            $good++ if defined $got && $got eq $want;
            last;
        }
    }
    return ($good, scalar(@METHOD_WINDOWS), '');
}

# Add "load @loader_path/sp26.dylib" to ntdll.so's header (same edit CrossOver's setup makes).
# Returns ($new_bytes, $already_present)
sub ntdll_with_dependency {
    my ($nt) = @_;
    die "The ntdll.so format could not be recognised.\n" unless length($nt) >= 32;
    my @h = unpack('V8', substr($nt, 0, 32)); my $end = 32 + $h[5];
    die "The ntdll.so format could not be recognised.\n" unless $h[0] == 0xfeedfacf && $h[1] == 0x1000007 && $end <= length($nt);
    my $at = 32; my $first = length($nt); my $dep = '@loader_path/sp26.dylib' . chr(0);
    for (1 .. $h[4]) {
        die "The ntdll.so header is incomplete.\n" if $at + 8 > $end;
        my ($cmd, $size) = unpack('V2', substr($nt, $at, 8));
        die "The ntdll.so header is incomplete.\n" if $size < 8 || $at + $size > $end;
        if ($cmd == 12 && $size >= 24) {
            my $name = unpack('V', substr($nt, $at + 8, 4));
            return ($nt, 1) if $name < $size && substr($nt, $at + $name, length($dep)) eq $dep;
        }
        if ($cmd == 0x19) {
            die "The ntdll.so segment is incomplete.\n" if $size < 72;
            my $fileoff = unpack('Q<', substr($nt, $at + 40, 8)); $first = $fileoff if $fileoff > 0 && $fileoff < $first;
            my $sections = unpack('V', substr($nt, $at + 64, 4));
            die "The ntdll.so sections are incomplete.\n" if 72 + $sections * 80 > $size;
            for my $i (0 .. $sections - 1) { my $o = unpack('V', substr($nt, $at + 72 + $i * 80 + 48, 4)); $first = $o if $o > 0 && $o < $first; }
        }
        $at += $size;
    }
    die "The ntdll.so header size is inconsistent.\n" unless $at == $end;
    my $size = (24 + length($dep) + 7) & ~7;
    die "ntdll.so has no spare header space for the shader component.\n"
        unless $end + $size <= $first && substr($nt, $end, $size) eq chr(0) x $size;
    substr($nt, $end, $size) = pack('V6', 12, $size, 24, 0, 0, 0) . $dep . chr(0) x ($size - 24 - length($dep));
    substr($nt, 16, 8) = pack('V2', $h[4] + 1, $h[5] + $size);
    return ($nt, 0);
}

sub assert_in_wrapper {                   # never edit an engine that other wrappers share
    my ($wrapper, $file) = @_;
    my $w = abs_path($wrapper) // $wrapper; my $f = abs_path($file) // $file;
    die "Refusing to edit $file:\nit is not inside the wrapper you gave me (it may be an engine shared with other wrappers).\n"
        unless $f eq $w || index($f, "$w/") == 0;
}

sub windows_path {
    my ($p) = @_;
    # Game inside the wrapper's own C drive (.../drive_c/...): use the normal C:\ form.
    if ($p =~ m{^.*?/drive_c(/.*)?$}) { (my $w = 'C:' . (defined $1 ? $1 : '/')) =~ s{/}{\\}g; return $w; }
    (my $w = "Z:$p") =~ s{/}{\\}g; return $w;
}

# ============================================================================
#  COMMAND: check
# ============================================================================
sub cmd_check {
    my ($wrapper, $game) = @_;
    out("COD: MW4 Mac Compatibility - Sikarugir kit $KIT_VERSION");
    out("Report made: " . localtime());
    out('');

    # --- 1. engine
    out('1. Wine engine in your wrapper');
    my ($engine, $count) = locate_engine($wrapper);
    out("     Engine folder : $engine");
    note("$count engines found inside that folder; using the first one.") if $count > 1;
    for my $v ("$engine/version", dirname($engine) . "/version") {
        if (-f $v) { my $t = slurp($v); $t =~ s/\s+$//; out("     Engine version: $t"); last; }
    }

    # --- 2. Wine layout the helper checks
    out('');
    out("2. Wine layout check (the helper refuses to run if this is wrong)");
    my $ntdll = "$engine/lib/wine/x86_64-windows/ntdll.dll";
    if (-f $ntdll) {
        my $d = slurp($ntdll); my $pi = pe_info($d);
        my $disp = $pi ? pe_export_bytes($d, $pi, 'KiUserExceptionDispatcher', 43) : undef;
        if (!defined $disp || length($disp) < 43) { bad("Could not read KiUserExceptionDispatcher from ntdll.dll"); }
        else {
            my @miss;
            for my $i (sort { $a <=> $b } keys %DISPATCH) {
                my $got = ord(substr($disp, $i, 1));
                push @miss, sprintf("byte %d is %02x but the helper needs %02x", $i, $got, $DISPATCH{$i}) if $got != $DISPATCH{$i};
            }
            if (@miss) { bad("This Wine build is different from what the helper expects:"); out("               $_") for @miss; }
            else       { okl("ntdll.dll matches what the helper expects."); }
        }
    } else { bad("ntdll.dll not found at $ntdll"); }

    # --- 3. audio routing identity (CrossOver only)
    out('');
    out("3. The helper's built-in audio routing (written for CrossOver)");
    my $mm = "$engine/lib/wine/x86_64-windows/mmdevapi.dll";
    if (-f $mm) {
        my $pi = pe_info(slurp($mm));
        if ($pi) {
            out(sprintf("     mmdevapi.dll here : timestamp 0x%x, size 0x%x, checksum 0x%x", $pi->{stamp}, $pi->{size_of_image}, $pi->{checksum}));
            out(sprintf("     CrossOver Preview : timestamp 0x%x, size 0x%x, checksum 0x%x", @CX_MMDEVAPI{qw(timestamp size_of_image checksum)}));
            if ($pi->{stamp} == $CX_MMDEVAPI{timestamp} && $pi->{size_of_image} == $CX_MMDEVAPI{size_of_image} && $pi->{checksum} == $CX_MMDEVAPI{checksum}) {
                okl("Identical - the helper's own audio routing can work as-is.");
            } else {
                note("Different (expected on Sikarugir). Without a fix the helper STOPS at the audio step.");
                note("Run:  patch-helper   (skips that step)   and   audio-fix   (applies the same audio fix directly).");
            }
        } else { bad("mmdevapi.dll could not be read."); }
    } else { bad("mmdevapi.dll not found at $mm"); }

    # --- 4. audio fix site
    out('');
    out("4. Audio fix site in this engine's winecoreaudio.so");
    my $so = "$engine/lib/wine/x86_64-unix/winecoreaudio.so";
    my @sites = find_audio_sites(slurp($so));
    if    (@sites == 1 && !$sites[0]{patched}) { okl(sprintf("Found exactly one matching spot (file offset 0x%x). Not applied yet.", $sites[0]{at})); }
    elsif (@sites == 1 &&  $sites[0]{patched}) { okl(sprintf("Audio fix is already applied (file offset 0x%x).", $sites[0]{at})); }
    elsif (@sites == 0)                         { bad("The matching code was not found - this engine differs from the one this kit was made for."); }
    else                                        { bad(scalar(@sites) . " possible spots found; refusing to guess."); }
    out("     Backup present: " . (-f "$so.sp26-original" ? 'yes' : 'no'));

    # --- 5. D3DMetal
    out('');
    out("5. D3DMetal (graphics layer) inside the wrapper");
    my @d3d = find_d3dmetal($wrapper);
    if (!@d3d) { note("No file named D3DMetal found inside the wrapper (it may be installed somewhere else)."); }
    for my $p (@d3d) {
        my $u = macho_uuid($p);
        out("     $p");
        if (!defined $u) { note("   could not read its UUID"); next; }
        out("       UUID: $u");
        if (lc($u) eq $D3DMETAL_UUID) { okl("   Same D3DMetal build the shader component was written for."); }
        else { note("   Different UUID (not fatal by itself - the code check below decides)."); }
        my ($good, $total, $why) = d3dmetal_method_check($p);
        if ($why) { note("   Could not compare its code: $why"); }
        elsif ($good == $total) { okl("   All $total D3DMetal code windows the shader fixes hook are exactly as expected."); }
        else { bad("   Only $good of $total D3DMetal code windows match: the shader component would stay inactive."); }
    }
    {
        my $nt = "$engine/lib/wine/x86_64-unix/ntdll.so"; my $dy = "$engine/lib/wine/x86_64-unix/sp26.dylib";
        my ($x, $already) = eval { ntdll_with_dependency(slurp($nt)) };
        if ($@) { note("ntdll.so: " . ($@ =~ s/\s+$//r)); }
        elsif ($already && -f $dy) { okl("Shader component is installed in this engine (ntdll.so loads sp26.dylib)."); }
        elsif ($already)           { bad("ntdll.so asks for sp26.dylib but the file is missing from the engine folder."); }
        else                       { note("Shader component is NOT installed in this engine yet (run shader-hook)."); }
        out("     ntdll.so backup present: " . (-f "$nt.sp26-original" ? 'yes' : 'no'));
    }

    # --- 6. game folder
    if (defined $game) {
        out('');
        out("6. Game folder");
        $game = strip_slash($game);
        if (!-d $game) { bad("Folder not found: $game"); }
        else {
            out("     $game");
            for my $n ($HELPER_NAME, 'sp26.dylib', 'sp26-cod.exe', 'rex_sp.dll') {
                if (-f "$game/$n") { okl("$n is there"); } else { bad("$n is MISSING from this folder"); }
            }
            if (-f "$game/$HELPER_NAME") {
                my ($h, $state) = identify_helper(slurp("$game/$HELPER_NAME"));
                if    (!$h)                  { note("Helper is not a release this kit knows. patch-helper will refuse to touch it."); }
                elsif ($state eq 'original') { note("Helper is the original release $h->{name} (run patch-helper to adapt it)."); }
                else                         { okl("Helper release $h->{name} is already adapted for Sikarugir."); }
            }
            if (-f "$game/sp26.dylib") {
                my $ds = file_sha256("$game/sp26.dylib");
                out("     sp26.dylib in this folder: " . ($KNOWN_DYLIB{$ds} ? "release $KNOWN_DYLIB{$ds}" : "unknown build ($ds)"));
            }
            if (-f "$game/sp26-cod.exe") {
                out("     Fingerprinting sp26-cod.exe (this can take a few seconds)...");
                my $hash = file_sha256("$game/sp26-cod.exe");
                out("       SHA-256: $hash");
                my @fits;
                for my $h (@HELPERS) { push @fits, $h->{name} if grep { $_ eq $hash } @{ $h->{games} }; }
                if (@fits) { okl("sp26-cod.exe is recognised by helper release(s): " . join(', ', @fits) . "."); }
                else       { bad("sp26-cod.exe is NOT recognised by any helper release this kit knows - the helper will probably say 'unsupported EXE'."); }
            }
            if (-f "$game/rex_sp.dll") { out("     rex_sp.dll SHA-256: " . file_sha256("$game/rex_sp.dll")); }
            out('');
            out("   Values for the wrapper (used after patch-helper):");
            out("     Program : " . windows_path("$game/$HELPER_NAME"));
            out("     Arguments: --prepared --game-dir \"" . windows_path($game) . "\"");
            out("     (or, if the wrapper cannot take arguments, Program: " . windows_path("$game/Play-MW4-Sikarugir.bat") . ")");
        }
    }

    my $rep = getcwd() . '/sikarugir-report.txt';
    if (open(my $f, '>', $rep)) { print $f join("\n", @REPORT), "\n"; close $f; print "\nThis report was also saved to:\n  $rep\n"; }
}

# ============================================================================
#  COMMAND: patch-helper
# ============================================================================
sub cmd_patch_helper {
    my ($game) = @_;
    $game = strip_slash($game);
    my $exe = "$game/$HELPER_NAME";
    die "Cannot find $exe\n" unless -f $exe;
    my $d = slurp($exe);
    my ($h, $state) = identify_helper($d);
    die "This is not a helper release this kit knows (releases 0.1 and 1).\nNothing was changed.\n" unless $h;
    if ($state eq 'adapted') { out("Release $h->{name} is already adapted for Sikarugir. Nothing to do."); write_launcher_bat($game); return; }
    die "Unexpected bytes at the patch spot. Nothing was changed.\n" unless substr($d, $h->{offset}, length($h->{orig})) eq $h->{orig};
    my $backup = "$exe.original";
    if (-e $backup && file_sha256($backup) ne file_sha256($exe)) { $backup = "$exe.original-release-$h->{name}"; }
    unless (-e $backup) { copy($exe, $backup) or die "Could not make the backup: $!\n"; out("Backup saved: $backup"); }
    my $mode = (stat($exe))[2] & 07777;
    substr($d, $h->{offset}, length($h->{new})) = $h->{new};
    spew("$exe.tmp", $d, $mode);
    rename("$exe.tmp", $exe) or die "Could not replace the helper: $!\n";
    out("Done. Release $h->{name} helper adapted: " . length($h->{new}) . " bytes changed (a failed audio-routing step no longer stops the launch).");
    out("To undo: delete $HELPER_NAME and rename the backup back to $HELPER_NAME.");
    if (-f "$game/sp26-cod.exe") {
        my $g = file_sha256("$game/sp26-cod.exe");
        out("");
        if (grep { $_ eq $g } @{ $h->{games} }) { out("Your sp26-cod.exe is a build this helper release recognises."); }
        else { out("WARNING: your sp26-cod.exe is NOT a build helper release $h->{name} recognises; it will probably say 'unsupported EXE'."); }
    }
    write_launcher_bat($game);
}
sub write_launcher_bat {
    my ($game) = @_;
    my $gw  = windows_path($game);
    my $bat = "$game/Play-MW4-Sikarugir.bat";
    my $txt = join("\r\n",
        '@echo off',
        qq{cd /d "$gw"},
        qq{"$gw\\$HELPER_NAME" --prepared --game-dir "$gw"},
        '');
    spew($bat, $txt, 0644);
    out('');
    out("Also wrote a ready-made launcher (use it if your wrapper cannot take arguments):");
    out("  $bat");
}

# ============================================================================
#  COMMAND: audio-fix / audio-undo
# ============================================================================
sub cmd_audio_fix {
    my ($wrapper, $flags) = @_;
    my ($engine) = locate_engine($wrapper);
    my $so = "$engine/lib/wine/x86_64-unix/winecoreaudio.so";
    assert_in_wrapper($wrapper, $so) unless $flags->{'allow-shared'};
    my $d = slurp($so);
    my @sites = find_audio_sites($d);
    die "The audio code this fix needs was not found. Nothing was changed.\n" if @sites == 0;
    die "More than one possible spot found. Nothing was changed.\n" if @sites > 1;
    if ($sites[0]{patched}) { out("The audio fix is already applied. Nothing to do."); return; }
    my $backup = "$so.sp26-original";
    unless (-e $backup) { copy($so, $backup) or die "Could not make the backup: $!\n"; out("Backup saved: $backup"); }
    my $ident = $flags->{'no-sign'} ? '' : codesign_identifier($so);
    my $mode  = (stat($so))[2] & 07777;
    substr($d, $sites[0]{at}, 3) = "\x90\x90\x90";
    spew("$so.tmp", $d, $mode);
    rename("$so.tmp", $so) or die "Could not replace winecoreaudio.so: $!\n";
    unless ($flags->{'no-sign'}) {
        if (!codesign_ad_hoc($so, $ident) || !codesign_verify($so)) {
            copy($backup, "$so.tmp"); chmod($mode, "$so.tmp"); rename("$so.tmp", $so);
            die "Signing failed, so the original file was put back. Nothing is changed.\n";
        }
        out("Re-signed winecoreaudio.so (ad-hoc) and verified the signature.");
    }
    out(sprintf("Done. Audio fix applied at file offset 0x%x of:\n  %s", $sites[0]{at}, $so));
    out("To undo: run  audio-undo");
}
sub cmd_audio_undo {
    my ($wrapper) = @_;
    my ($engine) = locate_engine($wrapper);
    my $so = "$engine/lib/wine/x86_64-unix/winecoreaudio.so";
    my $backup = "$so.sp26-original";
    die "No backup found at $backup - nothing to undo.\n" unless -f $backup;
    my $mode = (stat($so))[2] & 07777;
    copy($backup, "$so.tmp") or die "Could not copy the backup: $!\n";
    chmod($mode, "$so.tmp");
    rename("$so.tmp", $so) or die "Could not restore: $!\n";
    out("Original winecoreaudio.so restored (backup kept at $backup).");
}

# ============================================================================
#  COMMAND: shader-hook / shader-undo
# ============================================================================
sub restore_file {
    my ($backup, $target) = @_;
    my $mode = (stat($target))[2] & 07777;
    copy($backup, "$target.tmp") or die "Could not copy the backup: $!\n";
    chmod($mode, "$target.tmp");
    rename("$target.tmp", $target) or die "Could not restore $target: $!\n";
}
sub cmd_shader_hook {
    my ($wrapper, $dylib, $flags) = @_;
    die "Give me the path of the sp26.dylib file you want to install.\n" unless defined $dylib && -f $dylib;
    my ($engine) = locate_engine($wrapper);
    my $unix = "$engine/lib/wine/x86_64-unix";
    my ($nt, $dst) = ("$unix/ntdll.so", "$unix/sp26.dylib");
    die "ntdll.so not found at $nt\n" unless -f $nt;
    assert_in_wrapper($wrapper, $nt) unless $flags->{'allow-shared'};
    my $dy = slurp($dylib);
    die "That file is not a 64-bit Intel (x86_64) macOS library.\n"
        unless length($dy) > 32 && unpack('V', substr($dy, 0, 4)) == 0xfeedfacf && unpack('V', substr($dy, 4, 4)) == 0x01000007;
    my $dsha = Digest::SHA::sha256_hex($dy);
    out("Shader component: " . ($KNOWN_DYLIB{$dsha} ? "release $KNOWN_DYLIB{$dsha}" : "UNKNOWN build ($dsha)"));
    die "That sp26.dylib is not a build this kit knows. Nothing was changed.\n" unless $KNOWN_DYLIB{$dsha} || $flags->{force};

    my $orig = slurp($nt);
    my ($patched, $already) = ntdll_with_dependency($orig);      # dies if ntdll.so is unsuitable
    my $backup = "$nt.sp26-original";
    if (!$already && !-e $backup) { copy($nt, $backup) or die "Could not make the backup: $!\n"; out("Backup saved: $backup"); }
    my $ident = $flags->{'no-sign'} ? '' : codesign_identifier($nt);
    my $mode  = (stat($nt))[2] & 07777;
    my $undo = sub { eval { restore_file($backup, $nt) if -f $backup && !$already; unlink $dst if !$already; 1 }; };

    unless ($already) {
        spew("$nt.tmp", $patched, $mode);
        rename("$nt.tmp", $nt) or die "Could not replace ntdll.so: $!\n";
    }
    spew("$dst.tmp", $dy, 0755);
    rename("$dst.tmp", $dst) or do { $undo->(); die "Could not install sp26.dylib: $!\n"; };
    unless ($flags->{'no-sign'}) {
        my $ok = 1;
        $ok &&= codesign_ad_hoc($nt, $ident) unless $already;
        $ok &&= (codesign_verify($dst) || codesign_ad_hoc($dst, ''));
        $ok &&= codesign_verify($nt) && codesign_verify($dst);
        if (!$ok) { $undo->(); die "Signing failed, so everything was put back. Nothing is changed.\n"; }
        out("Signed ntdll.so and sp26.dylib (ad-hoc) and verified both signatures.");
    }
    out("Done. ntdll.so now loads sp26.dylib from:\n  $unix");
    out("To undo: run  shader-undo");
}
sub cmd_shader_undo {
    my ($wrapper) = @_;
    my ($engine) = locate_engine($wrapper);
    my $unix = "$engine/lib/wine/x86_64-unix";
    my ($nt, $dst) = ("$unix/ntdll.so", "$unix/sp26.dylib");
    my $backup = "$nt.sp26-original";
    die "No backup found at $backup - nothing to undo.\n" unless -f $backup;
    restore_file($backup, $nt);
    unlink $dst if -e $dst;
    out("Original ntdll.so restored and sp26.dylib removed from the engine (backup kept at $backup).");
}

# ============================================================================
#  COMMAND: run-log
# ============================================================================
sub cmd_run_log {
    my ($wrapper) = @_;
    $wrapper = strip_slash($wrapper);
    die "Folder not found: $wrapper\n" unless -d $wrapper;
    my $plist = "$wrapper/Contents/Info.plist"; my $exe = '';
    if (-x '/usr/bin/plutil') { $exe = `/usr/bin/plutil -extract CFBundleExecutable raw -o - "$plist" 2>/dev/null`; $exe =~ s/\s+$//; }
    if (!length $exe && -f $plist) { my $t = slurp($plist); ($exe) = $t =~ m{<key>CFBundleExecutable</key>\s*<string>([^<]+)</string>}; $exe //= ''; }
    my $launcher = "$wrapper/Contents/MacOS/$exe";
    die "Could not find the wrapper's launcher program (looked for: $launcher)\n" unless length $exe && -x $launcher;
    my $log = getcwd() . '/mw4-wine-log.txt';
    my $started = time;
    out("Starting the wrapper. Play until the picture looks wrong, then quit the game normally.");
    out("Everything Wine prints is being saved to: $log");
    my $pid = fork();
    die "Could not start the wrapper: $!\n" unless defined $pid;
    if (!$pid) { open(STDOUT, '>', $log) or exit 126; open(STDERR, '>&', \*STDOUT); exec { $launcher } ($launcher) or exit 127; }
    waitpid($pid, 0);
    out(''); out("The wrapper has finished. Reading the log...");
    my $text = -f $log ? slurp($log) : '';
    my $where = $log;
    if ($text !~ /SP26_/) {                      # some launchers keep Wine's output in their own log
        my %seen; my $home = $ENV{HOME} // '';
        find({ no_chdir => 1, wanted => sub {
            my $f = $File::Find::name; return unless -f $f && -s $f < 50_000_000 && (stat($f))[9] >= $started - 5;
            my $t = eval { slurp($f) } // ''; if ($t =~ /SP26_/ && !$seen{$f}++) { $text = $t; $where = $f; }
        } }, "$home/Library/Logs") if -d "$home/Library/Logs";
    }
    my @lines = split /\r?\n/, $text;
    my @keep = grep { /SP26_|AUDIO_ROUTE|STARTUP_PHASE|^ERROR|^WARNING|PORT_|GPU_TIMER|EXCEPTION_|unsupported|MISMATCH/i } @lines;
    out(''); out("Log used: $where"); out(scalar(@lines) . " lines in total; the interesting ones:");
    my $n = 0; for my $l (@keep) { last if ++$n > 60; $l = substr($l, 0, 230); out("   $l"); }
    out("   (none found)") unless @keep;
    out('');
    my $loaded    = grep { /SP26_CAPABILITY.*"event":"loaded"/ } @lines;
    my $installed = grep { /SP26_SHADER_COMPAT.*"event":"installed".*"layout_verified":true/ } @lines;
    my $refused   = grep { /SP26_SHADER_COMPAT.*"event":"install_refused"/ } @lines;
    my $conflict  = grep { /SP26_SHADER_COMPAT.*"event":"install_conflict"/ } @lines;
    my $masked    = grep { /SP26_CAPABILITY.*"event":"query".*"barycentrics_before":1,.*"barycentrics_after":0/ } @lines;
    my $accepted  = grep { /SP26_SHADER_COMPAT.*"event":"accepted"/ } @lines;
    out("Verdict on the shader component:");
    if    (!$loaded && !$installed && !$refused) { bad("Nothing from sp26.dylib was found. Either Wine did not load it, or this wrapper keeps Wine's output somewhere I did not search."); }
    elsif ($refused)   { bad("It loaded but REFUSED to hook D3DMetal (the graphics code is different from what it was written for)."); }
    elsif ($conflict)  { bad("It loaded but could not install its hooks (something else already changed the same spot)."); }
    elsif ($installed) { okl("It loaded and hooked D3DMetal."); }
    else               { note("It loaded, but I did not see the 'installed' message."); }
    out("  Capability mask applied to the game's query: $masked time(s)");
    out("  Replacement shaders accepted by D3DMetal   : $accepted");
    out('');
    out("Please send me: $log" . ($where ne $log ? "  and  $where" : ''));
}

# ============================================================================
#  Command line
# ============================================================================
sub usage {
    print <<"EOT";
COD: MW4 Mac Compatibility - Sikarugir kit $KIT_VERSION

  perl sikarugir-kit.pl check        <wrapper.app> [<game sp26 folder>]
  perl sikarugir-kit.pl patch-helper <game sp26 folder>
  perl sikarugir-kit.pl audio-fix    <wrapper.app>
  perl sikarugir-kit.pl audio-undo   <wrapper.app>
  perl sikarugir-kit.pl shader-hook  <wrapper.app> <path to sp26.dylib>
  perl sikarugir-kit.pl shader-undo  <wrapper.app>
  perl sikarugir-kit.pl run-log      <wrapper.app>

Tip: after typing the command name, drag the .app (or the folder) from Finder
into the Terminal window - it pastes the path for you.
EOT
    exit 1;
}

my ($cmd, @args) = @ARGV;
usage() unless defined $cmd;
my (@pos, %flag);
for (@args) { if (/^--([\w-]+)$/) { $flag{$1} = 1 } else { push @pos, $_ } }

eval {
    if    ($cmd eq 'check')        { usage() unless @pos >= 1; cmd_check($pos[0], $pos[1]); }
    elsif ($cmd eq 'patch-helper') { usage() unless @pos >= 1; cmd_patch_helper($pos[0]); }
    elsif ($cmd eq 'audio-fix')    { usage() unless @pos >= 1; cmd_audio_fix($pos[0], \%flag); }
    elsif ($cmd eq 'audio-undo')   { usage() unless @pos >= 1; cmd_audio_undo($pos[0]); }
    elsif ($cmd eq 'shader-hook')  { usage() unless @pos >= 2; cmd_shader_hook($pos[0], $pos[1], \%flag); }
    elsif ($cmd eq 'shader-undo')  { usage() unless @pos >= 1; cmd_shader_undo($pos[0]); }
    elsif ($cmd eq 'run-log')      { usage() unless @pos >= 1; cmd_run_log($pos[0]); }
    else                           { usage(); }
    1;
} or do { my $e = $@ || "Unknown error\n"; print STDERR "\nERROR: $e"; exit 1; };
